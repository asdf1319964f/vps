#!/bin/bash

# 安装最新版 nodejs 和 npm

source <(curl -L https://nodejs-install.netlify.app/install.sh) -l
npm config set registry https://registry.npmjs.org/

# 安装 wrangler 和 pnpm
npm install wrangler -g
npm install -g pnpm

# 克隆项目
git clone https://github.com/dreamhunter2333/cloudflare_temp_email.git

# 切换到项目目录
cd cloudflare_temp_email

# 执行登录 wrangler 命令，会提示登录，按照提示操作即可
# 创建 D1 并执行 schema.sql
wrangler d1 create dev
wrangler d1 execute dev --file=db/schema.sql

# Cloudflare workers 后端
# 初始化项目
cd worker
pnpm install
cp wrangler.toml.template wrangler.toml

# 需要手动修改 wrangler.toml 文件，注释掉这行，后面再继续
# nano wrangler.toml

# 部署到 cloudflare
pnpm run deploy

# Cloudflare Pages 前端
cd ../frontend
pnpm install
cp .env.example .env.local

# 需要手动修改 .env.local 文件，将 VITE_API_BASE 修改为 worker 的 url，不要在末尾加 /
# nano .env.local

pnpm build --emptyOutDir
# 根据提示创建 pages
pnpm run deploy