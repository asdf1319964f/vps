#!/bin/bash

# ANSI color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# Add a clear title
echo -e "${GREEN}Welcome to the Command Execution Menu${NC}"
echo "Please select an operation:"

# Define menu options (without colors)
options=(
  "rclone多功能"
  "dns检测"
  "ssh证书登陆"
  "匹配番号"
  "vps"
  "密码生成"
  "文件删除"
  "退出"
)

# Set the prompt for the select command with color
PS3=$'\033[0;32mEnter your choice: \033[0m'

# Display menu and get user selection
select choice in "${options[@]}"; do
  case $REPLY in
    1)
      echo -e "${GREEN}Executing rc.py...${NC}"
      python rc.py
      ;;
    2)
      echo -e "${GREEN}Executing dns.py...${NC}"
      python dns.py
      ;;
    3)
      echo -e "${GREEN}Executing ssh.sh...${NC}"
      ./ssh.sh
      ;;
    4)
      echo -e "${GREEN}Executing 重命名.py...${NC}"
      python 重命名.py
      ;;
    5)
      echo -e "${GREEN}Executing debian10.sh...${NC}"
      ./debian10.sh
      ;;
    6)
      echo -e "${GREEN}Executing debian10.sh...${NC}"
      python 密码生成.py
      ;;
    7)
      echo -e "${GREEN}Executing del.py...${NC}"
      python 根据关键词批量删除.py
      ;;
    8)
      echo -e "${RED}Exiting the menu...${NC}"
      break
      ;;
    *)
      echo -e "${RED}Invalid option: $REPLY${NC}"
      ;;
  esac
done

# Clear prompt after completion to let the user know the script has ended
echo -e "${GREEN}Operation completed.${NC}"