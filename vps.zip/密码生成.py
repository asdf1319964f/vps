import random
import string

def generate_random_password(length):
    '''生成指定长度的密码'''
    # 定义可选的字符集
    chars_set = string.ascii_letters + string.digits + string.punctuation
    # 从字符集中随机选择字符进行组合拼接至指定长度
    password = ''.join(random.choice(chars_set) for i in range(length))
    return password

def generate_user_password(num, psd_length):
    '''生成批量用户和密码'''
    user_passwords = []
    for i in range(num):
        # 调用生成指定长度密码的函数
        password = generate_random_password(psd_length)
        user_passwords.append(password)
    return user_passwords

# 生成10个长度为12的随机密码
passwords = generate_user_password(10, 12)
for password in passwords:
    print(password)
