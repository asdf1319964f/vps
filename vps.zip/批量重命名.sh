#!/bin/bash

txt_files_dir="FC2"
new_files_dir="FC2/new"

for file in "$txt_files_dir"/*.txt; do
    while IFS= read -r line; do
        if [[ $line == *.mp4 ]] || [[ $line == *.wmv ]] || [[ $line == *.ts ]] || [[ $line == *.avi ]] || [[ $line == *.iso ]]; then
            mkdir -p "$new_files_dir/${file%%.*}"
            touch "$new_files_dir/${file%%.*}/$line"
        elif [[ $line != *"."* ]]; then
            mkdir -p "$new_files_dir/${file%%.*}"
            touch "$new_files_dir/${file%%.*}/$line.mp4"
        fi
    done < "$file"
done