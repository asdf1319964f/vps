import os
import re

# 设置源目录和临时目录
source_dir = "写真:JAV"
temp_dir = "写真:JAV_temp"

# 列出源目录中的第一层子目录
subdirs = os.popen('rclone lsd "' + source_dir + '"').read().splitlines()

# 遍历每个第一层子目录并进行正则提取和重命名
for subdir in subdirs:
    match = re.search(r'\[(.*?)\]', subdir)
    if match:
        extracted_text = match.group(1)
        new_subdir = subdir.replace('[' + extracted_text + ']', extracted_text)
        # 将文件夹移动到临时目录
        os.system('rclone move "' + source_dir + '/' + subdir + '" "' + temp_dir + '/' + new_subdir + '"')

# 将文件夹从临时目录移回源目录
temp_subdirs = os.popen('rclone lsd "' + temp_dir + '"').read().splitlines()
for temp_subdir in temp_subdirs:
    os.system('rclone move "' + temp_dir + '/' + temp_subdir + '" "' + source_dir + '/' + temp_subdir + '"')
