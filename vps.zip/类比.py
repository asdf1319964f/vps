import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# 读取文件夹内所有.txt文件
def read_files_from_directory(directory):
    texts = []
    file_list = []
    for filename in os.listdir(directory):
        if filename.endswith(".txt"):
            filepath = os.path.join(directory, filename)
            with open(filepath, 'r', encoding='utf-8') as file:
                texts.append(file.read())
                file_list.append(filename)
    return texts, file_list

# 主函数
def main():
    directory_path = '国产'  # 替换为你的文件夹路径
    output_path = '重复.txt'  # 输出文件路径

    # 读取文件夹内的所有文本文件
    documents, file_list = read_files_from_directory(directory_path)
    
    if not documents:
        print("没有找到.txt文件")
        return

    # 计算TF-IDF
    tfidf_vectorizer = TfidfVectorizer()
    tfidf_matrix = tfidf_vectorizer.fit_transform(documents)

    # 计算所有文件之间的余弦相似度
    cosine_similarities = cosine_similarity(tfidf_matrix, tfidf_matrix)
    
    # 将结果写入到输出文件
    with open(output_path, 'w', encoding='utf-8') as f:
        for i, file_i in enumerate(file_list):
            for j, file_j in enumerate(file_list):
                if i < j:  # 只写入结果的上三角矩阵，避免重复
                    f.write(f"{file_i} 和 {file_j} 的余弦相似度: {cosine_similarities[i][j]:.4f}\n")

    print(f"结果已经写入到文件：{output_path}")

if __name__ == "__main__":
    main()
