#!/bin/bash

# 设置您的 SSH 私钥文件路径
PRIVATE_KEY_PATH="sh/id_rsa"

# 设置第二个目标 SSH 服务器的 IP 地址、登录账户和端口
TARGET_IP_1="107.174.34.100"
SSH_USER_1="root"
SSH_PORT_1="7626"

# 显示菜单并获取用户输入
echo "选择要连接的VPS:"
echo "1) VPS 1 - IP: $TARGET_IP_1, Port: $SSH_PORT_1"
read -p "请输入你的选择 (1): " user_choice

# 根据用户的选择进行连接
case $user_choice in
    1)
        echo "连接到VPS 1..."
        ssh -i $PRIVATE_KEY_PATH -p $SSH_PORT_1 $SSH_USER_1@$TARGET_IP_1
        ;;
    *)
        echo "无效的选项，脚本退出。"
        exit 1
        ;;
esac