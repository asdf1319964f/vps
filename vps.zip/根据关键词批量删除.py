import subprocess

# 加载你的关键词
with open("keywords.txt") as f:
    keywords = f.read().splitlines()

print("关键词列表:", keywords)

# 确保这是正确的远程名称
remote_name = "j7"  # 请确保这是你的远程名称
remote_config = '/data/data/com.termux/files/home/.config/rclone/rclone.conf'  # 确保这是正确的路径

# 遍历所有关键词
for keyword in keywords[:]:  # 使用关键词列表的副本进行迭代，以便在迭代中修改原始列表
    print(f"正在搜索关键词: {keyword}")
    # 使用rclone查找符合关键词的文件，不区分大小写
    find_cmd = ['rclone', '--config', remote_config, 'ls', f'{remote_name}:/', '--fast-list', '--max-depth', '1', '--include', f'*{keyword}*', '--ignore-case']
    try:
        result = subprocess.run(find_cmd, capture_output=True, text=True, timeout=60).stdout
        if result:
            print(f"找到匹配文件: {result}")
            files = result.strip().split('\n')
            for file in files:
                if file:
                    # 提取文件名
                    file_name = file.split()[-1]
                    print(f"准备删除文件: {file_name}")
                    delete_cmd = ['rclone', '--config', remote_config, 'delete', f'{remote_name}:/{file_name}', '--ignore-case']
                    try:
                        delete_result = subprocess.run(delete_cmd, capture_output=True, text=True, check=True)
                        print(f"已删除文件 '{file_name}'")
                        # 删除文件后，从关键词列表中移除该关键词
                        keywords.remove(keyword)
                    except subprocess.CalledProcessError as e:
                        print(f"删除文件 '{file_name}' 失败")
                        print(e.stderr)
        else:
            print(f"没有找到匹配关键词 '{keyword}' 的文件。")
    except KeyboardInterrupt:
        print("程序被用户中断")
        break
    except subprocess.TimeoutExpired:
        print(f"查找关键词 '{keyword}' 超时")
        continue

# 将更新后的关键词列表写回文件
with open("keywords.txt", 'w') as f:
    for keyword in keywords:
        f.write(keyword + '\n')