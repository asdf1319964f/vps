import subprocess
import json
import os
import re
from collections import defaultdict
# 列出远程内容
def list_remote_contents(rclone_config, remote_path):
    result = subprocess.run(["rclone", "lsjson", f"{rclone_config}:{remote_path}/"], capture_output=True, text=True)
    output = result.stdout.strip()
    if output:
        return json.loads(output)
    return []
# 查找重复内容
def find_duplicate_contents(directory):
    contents = defaultdict(list)
    duplicates = defaultdict(list)

    # 添加多个正则表达式模式
    regex_patterns = [
    r"\b[0-9a-zA-Z-]+\.(?!(mp4|wmv|flv|mkv|iso|m4v|avi)$)\b",
    r"^\d+[A-Z0-9]+-\d+\.mp4$",
    r"\b[a-zA-Z0-9]{4,}-\d{3}\b",
    r"^\d{6}-\d{3}-[a-zA-Z0-9-]+-\d+p\.mp4",
    r"^[A-Z0-9]+-\d+(_[A-Z0-9]+)?\.mp4",
    r"^[a-zA-Z0-9-]+\-\d+\.*[a-zA-Z0-9]*-\d+p\.mp4",
]

    ignored_text = r'\b(HD|1080p|_H|-U|-C|-UC|-c|-hd|-HD|_uncensored|-uncensored|-u|-c|WMV|_FHD|_HD|_hd)\b'

    for root, _, filenames in os.walk(directory):
        for filename in filenames:
            if filename.endswith(".txt"):
                file_path = os.path.join(root, filename)
                with open(file_path, "r", encoding="utf-8") as file:
                    data = file.read()
                    lines = data.split('\n')

                    for line_num, line in enumerate(lines, start=1):
                        # 标准化行文本为小写进行比较
                        line_lower = line.lower()
                        for pattern in regex_patterns:
                            matches = re.findall(pattern, line_lower)
                            for match in matches:
                                # 再次忽略用于比较的特定文本
                                if match and not re.search(ignored_text, match, re.IGNORECASE):
                                    contents[match].append((file_path, line_num))

    # 检查重复项
    for key, value in contents.items():
        if len(value) > 1:
            duplicates[key] = value

    return duplicates

# 提取包含关键词的内容
def extract_characters_with_keyword(input_string, keyword):
    result = re.findall(rf'.*{keyword}.*', input_string, re.IGNORECASE)
    return '\n'.join(result)

# 提取并保存包含关键词的内容
def extract_and_save_data(input_files, keyword, output_folder):
    found_data = []
    not_found_data = []

    for file_name in input_files:
        try:
            with open(file_name, 'r') as file:
                data = file.read()
                result = extract_characters_with_keyword(data, keyword)
                if result:
                    found_data.append((file_name, result))
                else:
                    not_found_data.append((file_name, "未找到包含关键词的内容"))
        except FileNotFoundError:
            print(f"文件 '{file_name}' 不存在.")

    # 将未找到内容追加到文件
    if not not_found_data:
        not_found_filename = os.path.join(output_folder, "未找到.txt")
        with open(not_found_filename, "a") as file:
            for file_name, message in not_found_data:
                file.write(f"文件：{file_name}\n")
                file.write(message + "\n")

    return found_data

# 保存结果到文件
def save_results_to_file(filename, data):
    with open(filename, "w") as file:
        for content, locations in data.items():
            file.write(f"{content} ")
            for location in locations:
                file.write(f"{location[0]} {location[1]} ")
            file.write("\n")

# 获取远程盘符容量
def get_remote_capacity(rclone_config):
    try:
        result = subprocess.run(["rclone", "about", f"{rclone_config}:"], capture_output=True, text=True, check=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        return f"获取容量失败：{e.stderr}"
# 主菜单
def main_menu():
    return_to_menu = True
    while True:
        if return_to_menu:
            print("\n请选择要执行的操作:")
            print("1. 列出远程内容")
            print("2. 查找重复内容")
            print("3. 提取包含关键词的内容")
            print("4. 显示远程盘符容量")
            print("5. 退出")
            choice = input("\n请输入选项: ")
        
        if choice == "1":
            rclone_configs = input("请输入 rclone 配置名，多个配置名用空格分隔：").split()
            for rclone_config in rclone_configs:
                remote_path = input(f"请输入远程路径 (默认为 /)：")
                if not remote_path:
                    remote_path = "/"
                remote_contents = list_remote_contents(rclone_config, remote_path)
                if remote_contents:
                    output_file = f"output/{rclone_config}.txt"
                    with open(output_file, "w") as file:
                        file.write(f"来自配置 {rclone_config} 的远程内容列表：\n")
                        for item in remote_contents:
                            file.write(item["Name"] + "\n")
                    print(f"来自配置 {rclone_config} 的远程内容已保存到 {output_file}")
                else:
                    print(f"来自配置 {rclone_config} 的远程内容为空.")
        
        elif choice == "2":
            directory = input("请输入要检查的目录：")
            duplicates = find_duplicate_contents(directory)
            if not duplicates:
                print("没有找到重复内容。")
            else:
                print("重复的内容：")
                save_results_to_file("out/查重.txt", duplicates)
                print("重复内容的结果已保存到 out/查重.txt 文件中.")
               
        elif choice == "3":
            while True:
                keyword = input("请输入关键词： ")
                input_files = []
                for root, _, files in os.walk("output"):  # 修改为遍历 "o" 文件夹
                    for file in files:
                        input_files.append(os.path.join(root, file))
                result = extract_and_save_data(input_files, keyword, "out")
                if result:
                    print("提取结果：")
                    for file_name, data in result:
                        print(f"文件：{file_name}")
                        print(data + "\n")
                else:
                    with open("out/未找到.txt", "a") as not_found_log:  # 使用追加模式 "a"
                        not_found_log.write(f"{keyword}\n")
                    print("未找到包含关键词的内容.")
            
        elif choice == "4":
            rclone_configs = input("请输入 rclone 配置名，多个配置名用空格分隔：").split()
            with open("out/总容量.txt", "a") as capacity_file:
                for rclone_config in rclone_configs:
                    capacity_info = get_remote_capacity(rclone_config)
                    capacity_file.write(f"来自配置 {rclone_config} 的容量信息：\n")
                    capacity_file.write(capacity_info)
                    capacity_file.write("\n")
                print("来自配置的容量信息已保存到 out/总容量.txt 文件。")
                
        elif choice == "5":
            print("退出程序。")
            break
        
        return_to_menu = True  # 重置返回到主菜单的标志

if __name__ == "__main__":
    main_menu()