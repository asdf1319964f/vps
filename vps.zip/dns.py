import os
import concurrent.futures
from datetime import datetime

def test_server(dns_server):
    """ Sends a single query to the DNS server. Returns the server and the time of the query """
    query_time = 0  # Set a default value for query_time
    start_time = datetime.now()
    os.system(f'dig +noall +stats @{dns_server} > dig.tmp')
    end_time = datetime.now()
    elapsed_time = (end_time - start_time).total_seconds()

    # Get the server query time
    with open('dig.tmp', 'r') as tmp_file:
        for line in tmp_file.readlines():
            if "Query time:" in line:
                query_time = int(line.split(':')[1].strip().split()[0])

    return dns_server, query_time, elapsed_time

def main():
    dns_servers = []
    with open("dns.txt", "r") as file:
        for line in file:
            dns_servers.append(line.strip())

    # Test all servers in parallel
    with concurrent.futures.ThreadPoolExecutor() as executor:
        results = list(executor.map(test_server, dns_servers))

    # Sort the servers by query time
    results.sort(key=lambda x: x[1])

    print('\nServers ranked by query time:')
    for result in results:
        print(f'Server: {result[0]}, Query time: {result[1]} ms, Elapsed time: {result[2]} s')

if __name__ == "__main__":
    main()
