import os
import subprocess

def list_files(drive_names):
    for drive_name in drive_names:
        command = f'rclone lsf -R {drive_name}:'  # rclone命令
        process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
        
        # 打开一个以盘符为名的文本文件，用于写入输出结果
        with open(f'{drive_name}.txt', 'w') as f: 
            while True:
                output = process.stdout.readline().decode()  # 从标准输出读取rclone的输出
                if output == '' and process.poll() is not None:
                    break
                if output:
                    f.write(output)

if __name__ == "__main__":
    drive_names = input("请输入你想要列出文件和目录的盘符，多个盘符请用逗号分隔：")  # 用户输入盘符
    drive_names = drive_names.split(",")  # 使用逗号分隔的盘符转化为列表
    list_files(drive_names)