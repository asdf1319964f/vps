import os
import collections

def read_files(path):
    # 创建一个字典来存储行内容和文件名
    line_dict = collections.defaultdict(list)

    # 遍历目录下的所有文件
    for filename in os.listdir(path):
        if filename.endswith('.txt'):
            with open(os.path.join(path, filename), 'r', encoding='utf-8') as f:
                lines = f.readlines()
                for line in lines:
                    # 删除行尾的换行符并将文件名添加到行内容对应的列表中
                    line_dict[line.strip()].append(filename)

    return line_dict

def find_duplicates(line_dict):
    with open("error.txt", 'w', encoding='utf-8') as f:  # 新建或打开 error.txt 文件
        for line, files in line_dict.items():
            if len(files) > 1:
                f.write(f"{line}  {' '.join(files)}\n")  # 将结果写入 error.txt 文件

def main():
    path = '.'  # 当前目录
    line_dict = read_files(path)
    find_duplicates(line_dict)

if __name__ == "__main__":
    main()