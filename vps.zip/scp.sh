#!/bin/bash

# SSH 私钥文件路径
PRIVATE_KEY_PATH="/data/data/com.termux/files/home/.ssh/id_rsa"

# 第一个VPS的信息
SOURCE_IP="198.98.52.85"
SOURCE_PORT="2509"
SOURCE_USER="root"
SOURCE_PATH="/root/*" # 注意，这里使用通配符*来指代所有文件

# 第二个VPS的信息
DESTINATION_IP="107.174.33.143"
DESTINATION_PORT="7626"
DESTINATION_USER="root"
DESTINATION_PATH="/root/" # 目标路径为root目录

# 确认开始复制
read -p "即将从 $SOURCE_IP 的 /root 目录复制文件到 $DESTINATION_IP 的 /root 目录。继续？(y/n): " confirmation
if [ "$confirmation" != "y" ]; then
    echo "复制操作已取消。"
    exit 1
fi

# 使用 scp 进行文件复制
scp -i $PRIVATE_KEY_PATH -P $SOURCE_PORT -r $SOURCE_USER@$SOURCE_IP:$SOURCE_PATH -P $DESTINATION_PORT $DESTINATION_USER@$DESTINATION_IP:$DESTINATION_PATH

# 结束提示
echo "文件复制完成。"
