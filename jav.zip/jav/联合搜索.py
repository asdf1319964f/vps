import subprocess

def call_script(script_name):
    print(f"调用 {script_name}.py 脚本的输出：")
    subprocess.call(["python", f"{script_name}.py"])
    print()

def main():
    while True:
        print("=== 选项菜单 ===")
        print("1. 调用 自定义提取.py 脚本")
        print("2. 调用 多盘符查重.py 脚本")
        print("3. 调用 rclone多盘符自定义路径.py 脚本")
        print("4. 调用 关键词搜索.py 脚本")
        print("5. 退出")

        choice = input("请输入选项数字：")

        if choice == '1':
            call_script("自定义提取")
        elif choice == '2':
            call_script("多盘符查重")
        elif choice == '3':
            call_script("rclone多盘符自定义路径")
        elif choice == '4':
            call_script("关键词搜索")
        elif choice == '5':
            print("已退出。")
            break
        else:
            print("错误：无效的选项。")

if __name__ == "__main__":
    main()
