import os

def find_duplicates_in_files(folder_path):
    # 获取文件夹中的所有txt文件
    txt_files = [f for f in os.listdir(folder_path) if f.endswith('.txt')]
    
    # 创建一个字典，用于存储每个txt文件中的文件名
    file_dict = {}
    
    # 遍历每个txt文件，获取文件名并添加到字典中
    for txt_file in txt_files:
        file_path = os.path.join(folder_path, txt_file)
        with open(file_path, 'r') as file:
            # 使用rclone ls命令获取文件列表
            cmd = f"rclone ls {file_path}"
            result = os.popen(cmd).read()
            # 解析输出，提取文件名
            file_names = [line.split()[-1] for line in result.splitlines()]
            file_dict[txt_file] = set(file_names)
    
    # 查找重复的文件名
    duplicate_files = {}
    for file_name, files in file_dict.items():
        for file in files:
            if file not in duplicate_files:
                duplicate_files[file] = [file_name]
            else:
                duplicate_files[file].append(file_name)
    
    # 输出重复文件名及其所在的文本文件名
    output_path = os.path.join(folder_path, 'duplicate_values.txt')
    with open(output_path, 'w') as output_file:
        for file, file_names in duplicate_files.items():
            if len(file_names) > 1:
                output_file.write(f"重复文件名: {file}，出现在文件: {', '.join(file_names)}\n")

    print("重复文件名已查找并输出到 duplicate_values.txt 文件")

def main():
    print("=== 选项菜单 ===")
    print("1. 列出多个盘符路径下的文件并保存到txt文件")
    print("2. 查找重复文件名并输出结果到duplicate_values.txt")
    print("3. 退出")
    
    choice = input("请输入选项数字：")
    
    if choice == '1':
        print("请输入多个盘符，用空格分隔：")
        disk_list = input().split()
        
        for disk in disk_list:
            output_file = f"{disk}.txt"
            os.system(f"rclone ls {disk}: > {output_file}")
            
            print(f"盘符 {disk} 下的文件列表已保存到 {output_file}")
    
    elif choice == '2':
        folder_path = '/data/data/com.termux/files/home/jav'
        find_duplicates_in_files(folder_path)
        
    elif choice == '3':
        print("已退出。")
        
    else:
        print("错误：无效的选项。")

if __name__ == "__main__":
    main()
