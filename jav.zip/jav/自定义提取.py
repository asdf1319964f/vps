import re

def extract_characters_after_numbers(input_string):
    # 使用正则表达式提取数字后面的所有字符
    result = re.findall(r'\d+\s*(.*)', input_string)
    
    # 返回提取的结果，去除空格并用换行分隔
    return '\n'.join(result)

def main():
    print("请输入文件名，多个文件名请用空格分隔：")
    input_files = input().split()

    # 用于存储所有文件的内容
    all_data = ""

    # 读取每个文件的内容
    for file_name in input_files:
        try:
            with open(file_name, 'r') as file:
                data = file.read()
                all_data += data + "\n"  # 添加换行来分隔不同文件的内容
        except FileNotFoundError:
            print(f"文件 '{file_name}' 不存在。")

    # 提取数字后面的所有字符并用换行分隔
    result = extract_characters_after_numbers(all_data)

    # 输出结果到输出.txt文件
    output_file = '输出.txt'
    with open(output_file, 'w') as output:
        output.write(result)

    print("提取结果已保存到 输出.txt 文件。")

if __name__ == "__main__":
    main()
