import re

def extract_characters_with_keyword(input_string, keyword):
    # 使用正则表达式提取包含关键词的所有字符
    result = re.findall(rf'.*{keyword}.*', input_string, re.IGNORECASE)
    
    # 返回提取的结果，用换行分隔
    return '\n'.join(result)

def extract_from_files(input_files, keyword):
    # 用于存储包含关键词的所有内容及其所在的文件名称
    all_data = []

    # 读取每个文件的内容并查找包含关键词的内容
    for file_name in input_files:
        try:
            with open(file_name, 'r') as file:
                data = file.read()
                result = extract_characters_with_keyword(data, keyword)
                if result:
                    all_data.append((file_name, result))
        except FileNotFoundError:
            print(f"文件 '{file_name}' 不存在。")

    return all_data

def main():
    print("请输入关键词：")
    keyword = input()

    print("请输入文件名，多个文件名请用空格分隔：")
    input_files = input().split()
    result = extract_from_files(input_files, keyword)
    
    if result:
        output_file = '关键词.txt'
        with open(output_file, 'w') as output:
            output.write("提取结果：\n")
            for file_name, data in result:
                output.write(f"文件：{file_name}\n")
                output.write(data + "\n\n")
        
        print("提取结果已保存到 关键词.txt 文件。")
    else:
        print("未找到包含关键词的内容。")

if __name__ == "__main__":
    main()
