#!/bin/bash

# 检查是否提供了新的端口号
if [ -z "$1" ]; then
  echo "Usage: $0 <new_port>"
  exit 1
fi

NEW_PORT=$1

# 备份现有的sshd_config文件
sudo cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak

# 更改端口号
sudo sed -i "s/^#Port 22/Port $NEW_PORT/" /etc/ssh/sshd_config
sudo sed -i "s/^Port [0-9]*/Port $NEW_PORT/" /etc/ssh/sshd_config

# 重新启动SSH服务
sudo systemctl restart ssh

# 确认更改
if sudo ss -tuln | grep -q ":$NEW_PORT"; then
  echo "SSH port changed to $NEW_PORT and service restarted successfully."
else
  echo "Failed to change SSH port."
fi