import os

def read_all_files():
    """读取当前文件夹中所有文本文件的内容"""
    all_items = set()
    for filename in os.listdir('.'):
        if filename.endswith('.txt'):
            with open(filename, 'r', encoding='utf-8') as file:
                all_items.update(file.read().splitlines())
    return all_items

def write_results(results, output_file):
    """将结果写入输出文件"""
    with open(output_file, 'w', encoding='utf-8') as file:
        for item in sorted(results):
            file.write(f"{item}\n")

def main():
    output_file = 'all_unique_items.txt'  # 结果输出文件

    # 读取所有文件并提取唯一项
    unique_items = read_all_files()

    # 将结果写入输出文件
    write_results(unique_items, output_file)

    print(f"处理完成。所有唯一项已保存到 {output_file}")
    print(f"共找到 {len(unique_items)} 个唯一项")

if __name__ == "__main__":
    main()
